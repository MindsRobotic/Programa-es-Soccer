#include <Wire.h>

// === CONFIGURAÇÕES ===
#define COMPASS_ADDR 0x01
#define ANGLE_MARGIN 2  // margem de erro em graus

// === PID ===
float Kp = 2.0;
float Ki = 0.01;
float Kd = 1.5;

float erroAnterior = 0;
float erroAcumulado = 0;
unsigned long ultimoTempo = 0;

// === PINOS DOS MOTORES ===
const int M1_IN1 = 7; const int M1_IN2 = 6; // Esquerda
const int M2_IN1 = 5; const int M2_IN2 = 4; // Trás
const int M3_IN1 = 3; const int M3_IN2 = 2; // Direita

int frenteRobo = 0;

void setup() {
  Serial.begin(9600);
  Wire.begin();

  pinMode(M1_IN1, OUTPUT); pinMode(M1_IN2, OUTPUT);
  pinMode(M2_IN1, OUTPUT); pinMode(M2_IN2, OUTPUT);
  pinMode(M3_IN1, OUTPUT); pinMode(M3_IN2, OUTPUT);

  delay(500);  // tempo para estabilizar a bússola
  frenteRobo = readCompass();  // define frente como zero
  ultimoTempo = millis();

  Serial.print("Frente inicial definida como: ");
  Serial.print(frenteRobo);
  Serial.println("°");
}

int readCompass() {
  Wire.beginTransmission(COMPASS_ADDR);
  Wire.write(0x42);
  Wire.endTransmission();

  Wire.requestFrom(COMPASS_ADDR, 2);
  if (Wire.available() >= 2) {
    uint8_t msb = Wire.read();
    uint8_t lsb = Wire.read();
    return ((msb << 8) + lsb) / 10;
  }
  return -1;
}

// === Cálculo de erro relativo entre -180° e +180° ===
int calcularErroRelativo() {
  int atual = readCompass();
  if (atual == -1) return 999;

  int erro = atual - frenteRobo;

  if (erro > 180) erro -= 360;
  if (erro < -180) erro += 360;

  return erro;
}

// === Gira no sentido horário (força máxima) ===
void girarHorario() {
  digitalWrite(M1_IN1, HIGH); digitalWrite(M1_IN2, LOW);
  digitalWrite(M2_IN1, HIGH); digitalWrite(M2_IN2, LOW);
  digitalWrite(M3_IN1, HIGH); digitalWrite(M3_IN2, LOW);
}

// === Gira no sentido anti-horário (força máxima) ===
void girarAntiHorario() {
  digitalWrite(M1_IN1, LOW); digitalWrite(M1_IN2, HIGH);
  digitalWrite(M2_IN1, LOW); digitalWrite(M2_IN2, HIGH);
  digitalWrite(M3_IN1, LOW); digitalWrite(M3_IN2, HIGH);
}

// === Para todos os motores ===
void pararMotores() {
  digitalWrite(M1_IN1, LOW); digitalWrite(M1_IN2, LOW);
  digitalWrite(M2_IN1, LOW); digitalWrite(M2_IN2, LOW);
  digitalWrite(M3_IN1, LOW); digitalWrite(M3_IN2, LOW);
}

void loop() {
  int erro = calcularErroRelativo();

  if (erro == 999) {
    Serial.println("Erro na leitura da bússola!");
    pararMotores();
    return;
  }

  Serial.print("Erro: ");
  Serial.println(erro);

  // Verifica se está dentro da margem
  if (abs(erro) <= ANGLE_MARGIN) {
    pararMotores();
    erroAcumulado = 0;
    erroAnterior = 0;
    Serial.println("Robô alinhado com a direção inicial!");
    delay(100);
    return;
  }

  // === Cálculo do PID ===
  unsigned long agora = millis();
  float deltaT = (agora - ultimoTempo) / 1000.0;
  ultimoTempo = agora;

  erroAcumulado += erro * deltaT;
  float derivada = (erro - erroAnterior) / deltaT;
  float saidaPID = Kp * erro + Ki * erroAcumulado + Kd * derivada;
  erroAnterior = erro;

  Serial.print("Saída PID: ");
  Serial.println(saidaPID);

  // === Aplica giro no sentido do erro ===
  if (saidaPID > 0) {
    girarHorario();
    Serial.println("Girando horário...");
  } else {
    girarAntiHorario();
    Serial.println("Girando anti-horário...");
  }

  delay(50);
}
