#include <Wire.h>

void setup() {
Wire.begin();
Serial.begin(9600);
Serial.println("Iniciando leitura do sensor IR Seeker V2...");
}

void loop() {
Wire.beginTransmission(0x08); // Endereço I2C do sensor
Wire.write(0x42); // Registro de direção
Wire.endTransmission();
Wire.requestFrom(0x08, 1);
if (Wire.available()) {
byte direction = Wire.read();
Serial.print("Direção: ");
Serial.println(direction);
}

Wire.beginTransmission(0x08);
Wire.write(0x49); // Registro de intensidade
Wire.endTransmission();
Wire.requestFrom(0x08, 1);
if (Wire.available()) {
byte strength = Wire.read();
Serial.print("Intensidade: ");
Serial.println(strength);
}

delay(100);
}