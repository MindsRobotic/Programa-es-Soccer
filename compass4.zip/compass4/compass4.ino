#include <Wire.h>

int compassAddress = 0x01;
int TestValue;
int frenteRobo = 0;
const int ANGLE_MARGIN = 5;

// Se o sensor estiver virado 90° à esquerda da frente real, coloque:
const int COMPASS_OFFSET = 185;  // pode ser 0, 90, 180 ou -90 dependendo da montagem

// Pinos dos motores
const int M1_IN1 = 7; const int M1_IN2 = 6;
const int M2_IN1 = 5; const int M2_IN2 = 4;
const int M3_IN1 = 3; const int M3_IN2 = 2;

void setup() {
  Serial.begin(9600);
  
  Wire.begin();
  Wire.beginTransmission(compassAddress);
  Wire.write(0x00);
  Wire.endTransmission();
  while (Wire.available() > 0) Wire.read();

  // Lê a frente com correção do sensor
  ReadCompassSensor();
  frenteRobo = (TestValue + COMPASS_OFFSET) % 360;
  Serial.print("Frente definida como: ");
  Serial.println(frenteRobo);

  pinMode(M1_IN1, OUTPUT); pinMode(M1_IN2, OUTPUT);
  pinMode(M2_IN1, OUTPUT); pinMode(M2_IN2, OUTPUT);
  pinMode(M3_IN1, OUTPUT); pinMode(M3_IN2, OUTPUT);
}

void loop() {
  ReadCompassSensor();
  int erro = calcularErroRelativo(TestValue, frenteRobo);

  Serial.print("Erro relativo: ");
  Serial.println(erro);

  if (abs(erro) <= ANGLE_MARGIN) {
    andarFrente();
    Serial.println("Alinhado! Indo pra frente.");
  } else if (erro > 0) {
    girarHorario();
    Serial.println("Girando horário...");
  } else {
    girarAntiHorario();
    Serial.println("Girando anti-horário...");
  }

  delay(50);
}

void ReadCompassSensor() {
  Wire.beginTransmission(compassAddress);
  Wire.write(0x44);
  Wire.endTransmission();

  Wire.requestFrom(compassAddress, 2);
  while (Wire.available() < 2);
  byte lowbyte = Wire.read();
  byte highbyte = Wire.read();
  TestValue = word(highbyte, lowbyte);
}

int calcularErroRelativo(int atual, int base) {
  int erro = atual - base;
  if (erro > 180) erro -= 360;
  if (erro < -180) erro += 360;
  return erro;
}

void girarHorario() {
  digitalWrite(M1_IN1, HIGH); digitalWrite(M1_IN2, LOW);
  digitalWrite(M2_IN1, HIGH); digitalWrite(M2_IN2, LOW);
  digitalWrite(M3_IN1, HIGH); digitalWrite(M3_IN2, LOW);
}

void girarAntiHorario() {
  digitalWrite(M1_IN1, LOW); digitalWrite(M1_IN2, HIGH);
  digitalWrite(M2_IN1, LOW); digitalWrite(M2_IN2, HIGH);
  digitalWrite(M3_IN1, LOW); digitalWrite(M3_IN2, HIGH);
}

void andarFrente() {
  digitalWrite(M1_IN1, LOW);  digitalWrite(M1_IN2, HIGH);
  digitalWrite(M2_IN1, HIGH); digitalWrite(M2_IN2, LOW);
  digitalWrite(M3_IN1, LOW);  digitalWrite(M3_IN2, HIGH);
}

void pararMotores() {
  digitalWrite(M1_IN1, LOW); digitalWrite(M1_IN2, LOW);
  digitalWrite(M2_IN1, LOW); digitalWrite(M2_IN2, LOW);
  digitalWrite(M3_IN1, LOW); digitalWrite(M3_IN2, LOW);
}
