#include <Wire.h>
#include <HTInfraredSeeker.h>

// Pinos dos motores
const int M1_IN1 = 7; // Esquerda
const int M1_IN2 = 6;
const int M2_IN1 = 5; // Trás
const int M2_IN2 = 4;
const int M3_IN1 = 3; // Direita
const int M3_IN2 = 2;

// Variáveis
int direcao;
int intensidade;
int velocidadeFrente = 255;
int velocidadeGiro = 200;
float Kp = 2.0;
float Ki = 2.5; // Novo ganho integral
float erroAcumulado = 0;

void setup() {
Serial.begin(9600);
InfraredSeeker::Initialize();

pinMode(M1_IN1, OUTPUT); pinMode(M1_IN2, OUTPUT);
pinMode(M2_IN1, OUTPUT); pinMode(M2_IN2, OUTPUT);
pinMode(M3_IN1, OUTPUT); pinMode(M3_IN2, OUTPUT);
}

void parar() {
analogWrite(M1_IN1, 0); analogWrite(M1_IN2, 0);
analogWrite(M2_IN1, 0); analogWrite(M2_IN2, 0);
analogWrite(M3_IN1, 0); analogWrite(M3_IN2, 0);
}

void frenteComCorrecao(int erro, int velocidade) {
erroAcumulado += erro; // Acumula o erro ao longo do tempo
float correcao = Kp * erro + Ki * erroAcumulado;

int velocidadeEsquerda = constrain(velocidade - correcao, 0, 255);
int velocidadeDireita = constrain(velocidade + correcao, 0, 255);

analogWrite(M1_IN1, velocidadeEsquerda); analogWrite(M1_IN2, 0);
analogWrite(M2_IN1, 0); analogWrite(M2_IN2, 0);
analogWrite(M3_IN1, velocidadeDireita); analogWrite(M3_IN2, 0);
}

void girarEsquerda(int velocidade) {
analogWrite(M1_IN1, 0); analogWrite(M1_IN2, velocidade);
analogWrite(M2_IN1, 0); analogWrite(M2_IN2, velocidade);
analogWrite(M3_IN1, velocidade); analogWrite(M3_IN2, 0);
}

void girarDireita(int velocidade) {
analogWrite(M1_IN1, velocidade); analogWrite(M1_IN2, 0);
analogWrite(M2_IN1, velocidade); analogWrite(M2_IN2, 0);
analogWrite(M3_IN1, 0); analogWrite(M3_IN2, velocidade);
}

void loop() {
InfraredResult bola = InfraredSeeker::ReadAC();
direcao = bola.Direction;
intensidade = bola.Strength;

Serial.print("Direção: "); Serial.print(direcao);
Serial.print(" | Intensidade: "); Serial.println(intensidade);

// Verifica se a bola está visível
if (direcao == 0 || intensidade < 5) {
parar();
erroAcumulado = 0; // Zera a memória do erro
return;
}

// Ajuste de velocidade com base na proximidade da bola
if (intensidade >= 200) {
velocidadeFrente = 120;
velocidadeGiro = 100;
} else {
velocidadeFrente = 255;
velocidadeGiro = 200;
}

// Controle com base na direção da bola
if (direcao >= 4 && direcao <= 6) {
int erro = 5 - direcao;
frenteComCorrecao(erro, velocidadeFrente);
} else if (direcao < 4) {
girarEsquerda(velocidadeGiro);
erroAcumulado = 0; // Evita erro acumulado indevido
} else if (direcao > 6) {
girarDireita(velocidadeGiro);
erroAcumulado = 0;
}

delay(50);
}