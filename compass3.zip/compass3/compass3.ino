#include <Wire.h>

#define COMPASS_ADDR 0x01
#define ANGLE_MARGIN 3          // Margem de tolerância para parar
#define CICLOS_ESTAVEL 5        // Número de ciclos dentro da margem para considerar alinhado

// PID
float Kp = 2.0;
float Ki = 0.01;
float Kd = 1.5;

float erroAnterior = 0;
float erroAcumulado = 0;
unsigned long ultimoTempo = 0;

int ciclosDentroDaMargem = 0;

// Pinos dos motores
const int M1_IN1 = 7; const int M1_IN2 = 6;
const int M2_IN1 = 5; const int M2_IN2 = 4;
const int M3_IN1 = 3; const int M3_IN2 = 2;

int frenteRobo = 0;

void setup() {
  Serial.begin(9600);
  Wire.begin();

  pinMode(M1_IN1, OUTPUT); pinMode(M1_IN2, OUTPUT);
  pinMode(M2_IN1, OUTPUT); pinMode(M2_IN2, OUTPUT);
  pinMode(M3_IN1, OUTPUT); pinMode(M3_IN2, OUTPUT);

  delay(500); // espera a bússola estabilizar
  frenteRobo = readCompass();
  ultimoTempo = millis();

  Serial.print("Frente inicial definida como: ");
  Serial.print(frenteRobo);
  Serial.println("°");
}

int readCompass() {
  Wire.beginTransmission(COMPASS_ADDR);
  Wire.write(0x42);
  Wire.endTransmission();

  Wire.requestFrom(COMPASS_ADDR, 2);
  if (Wire.available() >= 2) {
    uint8_t msb = Wire.read();
    uint8_t lsb = Wire.read();
    return ((msb << 8) + lsb) / 10;
  }
  return -1;
}

int calcularErroRelativo() {
  int atual = readCompass();
  if (atual == -1) return 999;

  int erro = atual - frenteRobo;

  if (erro > 180) erro -= 360;
  if (erro < -180) erro += 360;

  return erro;
}

void girarHorario() {
  digitalWrite(M1_IN1, HIGH); digitalWrite(M1_IN2, LOW);
  digitalWrite(M2_IN1, HIGH); digitalWrite(M2_IN2, LOW);
  digitalWrite(M3_IN1, HIGH); digitalWrite(M3_IN2, LOW);
}

void girarAntiHorario() {
  digitalWrite(M1_IN1, LOW); digitalWrite(M1_IN2, HIGH);
  digitalWrite(M2_IN1, LOW); digitalWrite(M2_IN2, HIGH);
  digitalWrite(M3_IN1, LOW); digitalWrite(M3_IN2, HIGH);
}

void pararMotores() {
  digitalWrite(M1_IN1, LOW); digitalWrite(M1_IN2, LOW);
  digitalWrite(M2_IN1, LOW); digitalWrite(M2_IN2, LOW);
  digitalWrite(M3_IN1, LOW); digitalWrite(M3_IN2, LOW);
}

void loop() {
  int erro = calcularErroRelativo();

  if (erro == 999) {
    Serial.println("Erro na leitura da bússola!");
    pararMotores();
    return;
  }

  Serial.print("Erro: ");
  Serial.println(erro);

  // Checa se está dentro da margem
  if (abs(erro) <= ANGLE_MARGIN) {
    ciclosDentroDaMargem++;
    if (ciclosDentroDaMargem >= CICLOS_ESTAVEL) {
      pararMotores();
      erroAcumulado = 0;
      erroAnterior = 0;
      Serial.println("Alinhado e estável.");
      return;
    } else {
      Serial.println("Quase lá... estabilizando.");
      pararMotores();
      delay(40);
      return;
    }
  } else {
    ciclosDentroDaMargem = 0; // reset se sair da margem
  }

  // PID
  unsigned long agora = millis();
  float deltaT = (agora - ultimoTempo) / 1000.0;
  ultimoTempo = agora;

  erroAcumulado += erro * deltaT;
  float derivada = (erro - erroAnterior) / deltaT;
  float saidaPID = Kp * erro + Ki * erroAcumulado + Kd * derivada;
  erroAnterior = erro;

  Serial.print("Saída PID: ");
  Serial.println(saidaPID);

  if (saidaPID > 0) {
    girarHorario();
    Serial.println("Girando horário...");
  } else {
    girarAntiHorario();
    Serial.println("Girando anti-horário...");
  }

  delay(50);
}
