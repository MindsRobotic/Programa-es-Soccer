#include <Wire.h>

#define COMPASS_ADDR 0x01
#define ANGLE_MARGIN 3 // Tolerância de erro em graus
#define VELOCIDADE_GIRO 255

// === PINOS DOS MOTORES (IN1 e IN2) ===
const int M1_IN1 = 7; // Esquerda
const int M1_IN2 = 6;
const int M2_IN1 = 5; // Trás
const int M2_IN2 = 4;
const int M3_IN1 = 3; // Direita
const int M3_IN2 = 2;

int frenteRobo = 0;

void setup() {
Serial.begin(9600);
Wire.begin();

pinMode(M1_IN1, OUTPUT); pinMode(M1_IN2, OUTPUT);
pinMode(M2_IN1, OUTPUT); pinMode(M2_IN2, OUTPUT);
pinMode(M3_IN1, OUTPUT); pinMode(M3_IN2, OUTPUT);

delay(500); // Espera estabilizar
frenteRobo = readCompass(); // Salva direção inicial como "0° relativo"
Serial.print("Frente definida como: ");
Serial.print(frenteRobo);
Serial.println("°");
}

// === Lê a bússola e retorna ângulo absoluto (0 a 359) ===
int readCompass() {
Wire.beginTransmission(COMPASS_ADDR);
Wire.write(0x42); // Registro de leitura
Wire.endTransmission();

Wire.requestFrom(COMPASS_ADDR, 2);
if (Wire.available() >= 2) {
uint8_t msb = Wire.read();
uint8_t lsb = Wire.read();
return ((msb << 8) + lsb) / 10; // Converte para graus
}
return -1;
}

// === Converte direção absoluta para erro relativo em graus (de -180 a +180) ===
int calcularErroRelativo() {
int atual = readCompass();
if (atual == -1) return 999; // Valor fora do intervalo para indicar erro

int erro = (atual - frenteRobo + 360) % 360; // Erro entre 0 e 359

// Converte para intervalo de -180 a +180
if (erro > 180) erro -= 360;

return erro;
}

// === Gira no próprio eixo sentido horário ===
void girarHorario() {
digitalWrite(M1_IN1, HIGH); digitalWrite(M1_IN2, LOW);
digitalWrite(M2_IN1, HIGH); digitalWrite(M2_IN2, LOW);
digitalWrite(M3_IN1, HIGH); digitalWrite(M3_IN2, LOW);
}

// === Gira no próprio eixo sentido anti-horário ===
void girarAntiHorario() {
digitalWrite(M1_IN1, LOW); digitalWrite(M1_IN2, HIGH);
digitalWrite(M2_IN1, LOW); digitalWrite(M2_IN2, HIGH);
digitalWrite(M3_IN1, LOW); digitalWrite(M3_IN2, HIGH);
}

// === Para todos os motores ===
void pararMotores() {
digitalWrite(M1_IN1, LOW); digitalWrite(M1_IN2, LOW);
digitalWrite(M2_IN1, LOW); digitalWrite(M2_IN2, LOW);
digitalWrite(M3_IN1, LOW); digitalWrite(M3_IN2, LOW);
}

void loop() {
int erro = calcularErroRelativo();

if (erro == 999) {
Serial.println("Erro na leitura da bússola!");
pararMotores();
return;
}

Serial.print("Erro relativo ao ponto inicial: ");
Serial.print(erro);
Serial.println("°");

if (abs(erro) <= ANGLE_MARGIN) {
pararMotores();
Serial.println("Alinhado!");
} else if (erro > 0) {
girarHorario();
Serial.println("Girando horário...");
} else {
girarAntiHorario();
Serial.println("Girando anti-horário...");
}

delay(100);
}