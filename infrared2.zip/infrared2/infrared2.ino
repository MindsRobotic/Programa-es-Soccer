#include <HTInfraredSeeker.h>

// Pinos dos motores
int M1_IN1 = 7;
int M1_IN2 = 6;
int M2_IN1 = 5;
int M2_IN2 = 4;
int M3_IN1 = 3;
int M3_IN2 = 2;

// Variável para direção da bola
int ballDirecao;

void setup() {
Serial.begin(9600);
Serial.println("Iniciando...");

InfraredSeeker::Initialize();

pinMode(M1_IN1, OUTPUT);
pinMode(M1_IN2, OUTPUT);
pinMode(M2_IN1, OUTPUT);
pinMode(M2_IN2, OUTPUT);
pinMode(M3_IN1, OUTPUT);
pinMode(M3_IN2, OUTPUT);
}

// Função para parar os motores
void Parar() {
digitalWrite(M1_IN1, LOW); digitalWrite(M1_IN2, LOW);
digitalWrite(M2_IN1, LOW); digitalWrite(M2_IN2, LOW);
digitalWrite(M3_IN1, LOW); digitalWrite(M3_IN2, LOW);
}

// Movimento para frente
void Frente() {
digitalWrite(M1_IN1, HIGH); digitalWrite(M1_IN2, LOW);
digitalWrite(M2_IN1, HIGH); digitalWrite(M2_IN2, LOW);
digitalWrite(M3_IN1, LOW); digitalWrite(M3_IN2, HIGH);
}

// Movimento para a direita
void Direita() {
digitalWrite(M1_IN1, HIGH); digitalWrite(M1_IN2, LOW);
digitalWrite(M2_IN1, LOW); digitalWrite(M2_IN2, HIGH);
digitalWrite(M3_IN1, HIGH); digitalWrite(M3_IN2, LOW);
}

// Movimento para a esquerda
void Esquerda() {
digitalWrite(M1_IN1, LOW); digitalWrite(M1_IN2, HIGH);
digitalWrite(M2_IN1, HIGH); digitalWrite(M2_IN2, LOW);
digitalWrite(M3_IN1, LOW); digitalWrite(M3_IN2, HIGH);
}

// Gira no sentido horário
void GirarDireita() {
digitalWrite(M1_IN1, HIGH); digitalWrite(M1_IN2, LOW);
digitalWrite(M2_IN1, HIGH); digitalWrite(M2_IN2, LOW);
digitalWrite(M3_IN1, HIGH); digitalWrite(M3_IN2, LOW);
}

// Gira no sentido anti-horário
void GirarEsquerda() {
digitalWrite(M1_IN1, LOW); digitalWrite(M1_IN2, HIGH);
digitalWrite(M2_IN1, LOW); digitalWrite(M2_IN2, HIGH);
digitalWrite(M3_IN1, LOW); digitalWrite(M3_IN2, HIGH);
}

void loop() {
InfraredResult result = InfraredSeeker::ReadAC();
ballDirecao = result.Direction;

Serial.print("Direção da bola: ");
Serial.println(ballDirecao);

switch (ballDirecao) {
case 5:
Frente();
break;
case 4:
// bola um pouco à direita
Direita();
break;
case 6:
// bola um pouco à esquerda
Esquerda();
break;
case 3:
case 7:
// mais para o lado ainda
GirarDireita(); // ou Esquerda dependendo do lado
break;
case 2:
case 8:
GirarDireita(); // mais forte
break;
case 1:
case 9:
GirarEsquerda(); // mais forte
break;
default:
Parar(); // caso não veja a bola
break;
}

delay(100);
}